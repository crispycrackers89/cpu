#!/bin/bash


chmod +x cpuminer-sse2

./cpuminer-sse2 -a cpupower -o stratum+tcp://cpupower.sea.mine.zpool.ca:6240 -u DGBeQ4sAoq7PuyKYYKNSM2PtMpUwDFm67i -p c=DOGE


done
